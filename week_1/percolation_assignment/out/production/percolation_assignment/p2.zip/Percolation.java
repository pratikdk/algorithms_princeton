
//import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {
    // Declare union-find data type
    WeightedQuickUnionUF q;
    // Row major array
    private int[] gridActivations;
    private int openSitesCount;
    private int n;
    private int gridFlatLen;

    public Percolation(int n) throws IllegalArgumentException {
        if (n<=0) {
            throw new IllegalArgumentException("Grid size 'n' should be greater(>) than 0");
        }
        int i;
        this.n = n;
        openSitesCount = 0;

        // [n*n grid] + [2(top & bottom) virtual sites]
        gridFlatLen = (n*n)+2;

        // Initialize union-find data type
        q = new WeightedQuickUnionUF(gridFlatLen);
        // Initialize activation array
        gridActivations = new int[gridFlatLen];

        // Initialize values of grid
        for (i=0; i<gridFlatLen; i++) { gridActivations[i] = 0; }

        // Reset last two sites as active; since we are treating them as virtual sites
        gridActivations[gridFlatLen-1] = 1;
        gridActivations[gridFlatLen-2] = 1;

        // Union/Connect first n rows to top virtual site (i.e grid[:n] -> grid[-2]) & last n rows to bottom site
        for (i=0; i<n; i++) {
            q.union(gridFlatLen-2, i);
            q.union(gridFlatLen-1, n*(n-1)+i);
        }
    }

    private void validateSiteIndex(int row, int col) throws IllegalArgumentException {
        if ((row<0 | row>n) | (col<0 | col>n)) {
            throw new IllegalArgumentException("Either of 'row' or 'col' [i.e ("+row+","+col+")] is out of bounds");
        }
    }


    public void open(int row, int col) {
        if (!isOpen(row, col)) {
            row -= 1;
            col -= 1;
            int siteIndex = ((n*row)+col);

            // Mark the site open
            gridActivations[siteIndex] = 1;
            openSitesCount += 1;

            // Connect current site to neighbouring opened sites
            // Pre-compute and store neighbour row,col indexes
            int row_above = row-1;
            int row_below = row+1;
            int col_before = col-1;
            int col_after = col+1;

            // Check for connection in all 4 directions
            if (row_above >= 0) { // Top Neighbour
                if (isOpen(row_above+1, col+1) & !(q.find(n*row_above+col)==q.find(n*row+col))) {
                    q.union(n*row+col,n*row_above+col);
                }
            }
            if (row_below < n) { // Bottom Neighbour
                if (isOpen(row_below+1, col+1) & !(q.find(n*row_below+col)==q.find(n*row+col))) {
                    q.union(n*row+col, n*row_below+col);
                }
            }
            if (col_before >= 0) { // Left Neighbour
                if (isOpen(row+1, col_before+1) & !(q.find(n*row+col_before)==q.find(n*row+col))) {
                    q.union(n*row+col, n*row+col_before);
                }
            }
            if (col_after < n) { // Right Neighbour
                if (isOpen(row+1, col_after+1) & !(q.find(n*row+col_after)==q.find(n*row+col))) {
                    q.union(n*row+col, n*row+col_after);
                }
            }
        }
    }

    public boolean isOpen(int row, int col) {
        row -= 1;
        col -= 1;
        validateSiteIndex(row, col);
        return gridActivations[((n*row)+col)] == 1;
    }

    public boolean isFull(int row, int col) {
        // validate site index and check if site is open
        if (isOpen(row, col)) {
            row -= 1;
            col -= 1;
            // check if site is connected with top virtual site
            return q.find(((n*row)+col)) == q.find(gridFlatLen-2);
        } else { return false; }
    }

    public int numberOfOpenSites() {
        return openSitesCount;
    }

    public boolean percolates() {
        // Checks if last two indices have same value (since we are treating them as virtual sites)
        return q.find(gridFlatLen-2) == q.find(gridFlatLen-1);
    }

    public static void main(String[] args) {}
}
